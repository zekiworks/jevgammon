# Render comparison

## 1. Files
2552 files in origin/main's render, 2552 in the candidate's; only in one: none; different: ['index.html']

## 2. Rows and numbers
Leaderboard rows with a details box: origin/main 63, candidate 63.

Rows differing from origin/main beyond the Parameters line and data-hl-small: 0. Rows whose numbers (row + box, Parameters line out) differ: 0.

Home page outside the leaderboard table: text identical.

## 3-4. Parameters line and Small models flag vs model_params.json (threshold 15B)
63 of 63 rows ok; 1 rows changed.

| Box | Row | Setup | Model | origin/main | small (main) | candidate | Link | small | Change | OK |
|---|---|---|---|---|---|---|---|---|---|---|
| hl-1-box | model/main | GPT-6 Astra (high) | GPT-6 Astra | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-1-1-box | model/other | GPT-6 Astra (low) | GPT-6 Astra | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-1-2-box | model/other | GPT-6 Astra (medium) | GPT-6 Astra | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-2-box | model/main | Gemini 4 Argon (high) | Gemini 4 Argon | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-2-1-box | model/other | Gemini 4 Argon (low) | Gemini 4 Argon | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-3-box | model/main | Claude Fable 5.1 (high) | Claude Fable 5.1 | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-3-1-box | model/other | Claude Fable 5.1 (low) | Claude Fable 5.1 | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-4-box | model/main | GPT-6.1 Sol (high) | GPT-6.1 Sol | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-4-1-box | model/other | GPT-6.1 Sol (low) | GPT-6.1 Sol | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-5-box | model/main | Claude Opus 5.5 (high) | Claude Opus 5.5 | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-5-1-box | model/other | Claude Opus 5.5 (low) | Claude Opus 5.5 | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-6-box | model/main | DeepSeek V4.1 Flash (low) | DeepSeek V4.1 Flash | 552B backbone + 196B conditional memory; active 8B (prefill) / 16B (decode) |  | 552B backbone + 196B conditional memory; active 8B (prefill) / 16B (decode) | https://huggingface.co/deepseek-ai/DeepSeek-V4.1-Flash |  | same | yes |
| hl-6-1-box | model/other | DeepSeek V4.1 Flash 1017 (low) | DeepSeek V4.1 Flash 1017 | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-6-2-box | model/other | DeepSeek V4.1 Flash (off) | DeepSeek V4.1 Flash | 552B backbone + 196B conditional memory; active 8B (prefill) / 16B (decode) |  | 552B backbone + 196B conditional memory; active 8B (prefill) / 16B (decode) | https://huggingface.co/deepseek-ai/DeepSeek-V4.1-Flash |  | same | yes |
| hl-6-3-box | model/other | DeepSeek V4.1 Flash 1017 (off) | DeepSeek V4.1 Flash 1017 | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-7-box | model/main | Grok 4.7 (high) | Grok 4.7 | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-7-1-box | model/other | Grok 4.7 (low) | Grok 4.7 | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-8-box | model/main | Claude Sonnet 5.5 (high) | Claude Sonnet 5.5 | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-8-1-box | model/other | Claude Sonnet 5.5 (low) | Claude Sonnet 5.5 | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-9-box | model/main | Gemini 3.8 Flash (high) | Gemini 3.8 Flash | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-9-1-box | model/other | Gemini 3.8 Flash (low) | Gemini 3.8 Flash | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-10-box | model/main | Kimi K3.1 Pro (off) | Kimi K3.1 Pro | 2.8T total / 104B active |  | 2.8T total / 104B active | https://huggingface.co/moonshotai/Kimi-K3.1-Pro/blob/main/README.md |  | same | yes |
| hl-11-box | model/main | Gemma 4 31B (on) | Gemma 4 31B | 31.27B incl. its vision encoder |  | 31.27B incl. its vision encoder | https://huggingface.co/google/gemma-4-31B-it/tree/842da3794eaa0b77d5f08bae87a17459d91ff475 |  | same | yes |
| hl-11-1-box | model/other | Gemma 4 31B (off) | Gemma 4 31B | 31.27B incl. its vision encoder |  | 31.27B incl. its vision encoder | https://huggingface.co/google/gemma-4-31B-it/tree/842da3794eaa0b77d5f08bae87a17459d91ff475 |  | same | yes |
| hl-12-box | model/main | Liquid d1-ultra | Liquid d1-ultra | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-13-box | model/main | Base Labs Mammoth-1 | Base Labs Mammoth-1 | 27.36B incl. its vision encoder; card: 27B |  | 27.36B incl. its vision encoder; card: 27B | https://huggingface.co/baselabs/mammoth-1/tree/61cec44c281c693992e3d6ebeb44dd3402dfa186 |  | same | yes |
| hl-14-box | model/main | Drex Max v1 | Drex Max v1 | backbone 26.09B incl. its vision encoder + decision head 1.3M; card: 27B |  | backbone 26.09B incl. its vision encoder + decision head 1.3M; card: 27B | https://huggingface.co/nace-ai/drex-max-v1/tree/cac65e1982a0237e996419ba559004522d9a33ac |  | same | yes |
| hl-15-box | model/main | Qwen3.8-27B (low) | Qwen3.8-27B | 27.78B incl. its vision encoder; card: 27B |  | 27.78B incl. its vision encoder; card: 27B | https://huggingface.co/Qwen/Qwen3.8-27B/tree/37561816e66b5b9153b1b64c10968c18c1e6f4a0 |  | same | yes |
| hl-15-1-box | model/other | Qwen3.8-27B (off) | Qwen3.8-27B | 27.78B incl. its vision encoder; card: 27B |  | 27.78B incl. its vision encoder; card: 27B | https://huggingface.co/Qwen/Qwen3.8-27B/tree/37561816e66b5b9153b1b64c10968c18c1e6f4a0 |  | same | yes |
| hl-16-box | model/main | GLM-5.3 (low) | GLM-5.3 | 753.33B total; active not disclosed by maker |  | 753.33B total; active not disclosed by maker | https://huggingface.co/api/models/zai-org/GLM-5.3 |  | same | yes |
| hl-17-box | model/main | REAX 1.3 | REAX 1.3 | part G 31.27B + part Q 26.09B (each incl. its vision encoder) + decision head 1.3M |  | part G 31.27B + part Q 26.09B (each incl. its vision encoder) + decision head 1.3M | https://huggingface.co/decisionmodels/REAX-1.3/tree/fa4bf7ee3bb56a8bc421dad090631be1c5845c2d |  | same | yes |
| hl-18-box | model/main | Fastino GLiDE | Fastino GLiDE | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-19-box | model/main | Jev 1.13.0 | Jev 1.13.0 | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-20-box | model/main | Qwen3.8 Flash (off) | Qwen3.8 Flash | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-21-box | model/main | Jev 1.14.0 | Jev 1.14.0 | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-22-box | model/main | Drex Max 1.1 | Drex Max 1.1 | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-23-box | model/main | Fastino GLiDE v1.2 (local) | Fastino GLiDE v1.2 | backbone 26.09B incl. its vision encoder + decision head 1.3M |  | backbone 26.09B incl. its vision encoder + decision head 1.3M | https://huggingface.co/fastino/GLiDE-27B/tree/a7e45896be7c96ba3354891da790c5ec99c30b6c |  | same | yes |
| hl-24-box | model/main | Drex 2.0 | Drex 2.0 | 35.11B incl. a vision tower the card says is dropped on load; card: 35B; 3B active |  | 35.11B incl. a vision tower the card says is dropped on load; card: 35B; 3B active | https://huggingface.co/nace-ai/drex-v2.0/tree/e646674476744e3826caf62b834054151e2aba51 |  | same | yes |
| hl-24-1-box | model/other | Drex 2.0 (local) | Drex 2.0 | 35.11B incl. a vision tower the card says is dropped on load; card: 35B; 3B active |  | 35.11B incl. a vision tower the card says is dropped on load; card: 35B; 3B active | https://huggingface.co/nace-ai/drex-v2.0/tree/e646674476744e3826caf62b834054151e2aba51 |  | same | yes |
| hl-25-box | model/main | Decider v1.2 27B | Decider v1.2 27B | backbone 26.09B incl. its vision encoder + decision head 1.3M; changelog: 27B |  | backbone 26.09B incl. its vision encoder + decision head 1.3M; changelog: 27B | https://huggingface.co/perplexity-ai/pplx-decider-v1.2/tree/cce0f3f80033e9d89d80831d5281fd72124aacce |  | same | yes |
| hl-26-box | model/main | Celeris-1 Decision | Celeris-1 Decision | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-27-box | model/main | Base Labs Elephant-1 | Base Labs Elephant-1 | 9.41B incl. its vision encoder; card: 9B | yes | 9.41B incl. its vision encoder; card: 9B | https://huggingface.co/baselabs/elephant-1/tree/b3f8a93462fb1051a9de031e94a7ff380e254072 | yes | same | yes |
| hl-28-box | model/main | Clef | Clef | backbone 27.36B incl. its vision encoder + joint head 128.1M; card: 27B |  | backbone 27.36B incl. its vision encoder + joint head 128.1M; card: 27B | https://huggingface.co/Cloudflare/clef/tree/cfddda043dd190ef3b01cff449d5ee8cff1e8ec6 |  | same | yes |
| hl-29-box | model/main | Cygnet (Gemma 4 12B) | Cygnet (Gemma 4 12B) | 11.95B | yes | 11.96B incl. its vision encoder; card: 11.95B | https://huggingface.co/google/gemma-4-12B-it/tree/707f0a3b8a3c7ad586ed01e27eafbad8a27dd0f7 | yes | CHANGED | yes |
| hl-30-box | model/main | Decider v1.1 27B | Decider v1.1 27B | backbone 26.09B incl. its vision encoder + decision head 1.3M |  | backbone 26.09B incl. its vision encoder + decision head 1.3M | https://huggingface.co/perplexity-ai/pplx-decider-v1.1-27b/tree/14c9d90137962d300f3de95633f7b6535e80c5ce |  | same | yes |
| hl-31-box | model/main | SubQ Snap 1.1 | SubQ Snap 1.1 | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-32-box | model/main | SubQ Snap Preview | SubQ Snap Preview | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-33-box | model/main | GPT-6 Luna | GPT-6 Luna | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-34-box | model/main | Winnow-12B | Winnow-12B | 11.91B | yes | 11.91B | https://huggingface.co/EldanRing/Winnow-12B/blob/0b5b7f98e718cf0faffd0acea3093b86ebf00b56/gguf/Winnow-12B-Q8_0.gguf | yes | same | yes |
| hl-35-box | model/main | Mercury Decide | Mercury Decide | not disclosed by maker |  | not disclosed by maker |  |  | same | yes |
| hl-36-box | model/main | LFM2.5-24B-A2B (on) | LFM2.5-24B-A2B | 23.97B total / 2.45B active |  | 23.97B total / 2.45B active | https://huggingface.co/LiquidAI/LFM2.5-24B-A2B/tree/3dc4cd09c9a2a99e1e819693e79d3aba5e9bb4f2 |  | same | yes |
| hl-36-1-box | model/other | LFM2.5-24B-A2B (off) | LFM2.5-24B-A2B | 23.97B total / 2.45B active |  | 23.97B total / 2.45B active | https://huggingface.co/LiquidAI/LFM2.5-24B-A2B/tree/3dc4cd09c9a2a99e1e819693e79d3aba5e9bb4f2 |  | same | yes |
| hl-37-box | model/main | Decider Flash v1.2 | Decider Flash v1.2 | backbone 4.54B incl. its vision encoder + decision head 0.7M; changelog: 4B | yes | backbone 4.54B incl. its vision encoder + decision head 0.7M; changelog: 4B | https://huggingface.co/perplexity-ai/pplx-decider-flash-v1.2/tree/9ff7cf9838e59df461c276b7699d56b244d2af58 | yes | same | yes |
| hl-38-box | model/main | Open-Jev 27B v1.1 | Open-Jev 27B v1.1 | 27.80B: Qwen3.8-27B base 27.78B + adapter and head 15.47M (the repo holds only the adapter and head) |  | 27.80B: Qwen3.8-27B base 27.78B + adapter and head 15.47M (the repo holds only the adapter and head) | https://huggingface.co/ZefanCai/Open-Jev-27B-v1.1/tree/28cf73067d5b337860bbef3c85b8b82ba8730956 |  | same | yes |
| hl-p-1-box | program/main | GNUbg weak |  |  |  |  |  |  | same | yes |
| hl-p-1-1-box | program/other | GNUbg weak |  |  |  |  |  |  | same | yes |
| hl-p-1-2-box | program/other | GNUbg weak |  |  |  |  |  |  | same | yes |
| hl-p-2-box | program/main | Safest |  |  |  |  |  |  | same | yes |
| hl-p-2-1-box | program/other | Safest (computed) |  |  |  |  |  |  | same | yes |
| hl-p-2-2-box | program/other | Safest (computed) |  |  |  |  |  |  | same | yes |
| hl-p-3-box | program/main | Random |  |  |  |  |  |  | same | yes |
| hl-p-3-1-box | program/other | Random (computed) |  |  |  |  |  |  | same | yes |
| hl-p-3-2-box | program/other | Random (computed) |  |  |  |  |  |  | same | yes |

**Failures: 0**
