"""Logical parameter count of one safetensors file on Hugging Face from its header only (HTTP range requests): the sum
of the products of its tensors' shapes, per dtype; no weights downloaded.

    python3 st_header_count.py REPO REVISION FILE [FILE ...]"""
import json
import struct
import sys
import urllib.request
from math import prod

repo, rev, files = sys.argv[1], sys.argv[2], sys.argv[3:]


def get(url, a, b):
    req = urllib.request.Request(url, headers={"Range": f"bytes={a}-{b}"})
    with urllib.request.urlopen(req) as r:
        return r.read()


for fn in files:
    url = f"https://huggingface.co/{repo}/resolve/{rev}/{fn}"
    n = struct.unpack("<Q", get(url, 0, 7))[0]
    head = json.loads(get(url, 8, 8 + n - 1))
    meta = head.pop("__metadata__", None)
    by = {}
    for name, t in head.items():
        by.setdefault(t["dtype"], 0)
        by[t["dtype"]] += prod(t["shape"])
    print(f"{repo} @ {rev} {fn}: tensors {len(head)}; logical parameters {sum(by.values()):,} {by}; "
          f"names {sorted(head)[:6]}{' …' if len(head) > 6 else ''}; metadata {meta}")
