"""Palette table for maker-colours: CIEDE2000 between every two maker colours (and against the program greys), WCAG
contrast of each against the site's light and dark panel and page backgrounds (assets/site.css).

    python3 palette_check.py OLD_MAKER_COLORS_JSON NEW_MAKER_COLORS_JSON OUT.md
"""
import itertools
import json
import math
import sys

old, new = (json.load(open(p)) for p in sys.argv[1:3])
BG = {"light panel #f7f6f2": "#f7f6f2", "light page #dcd9d2": "#dcd9d2", "dark panel #1a1a18": "#1a1a18",
      "dark page #0e0e0d": "#0e0e0d"}
GREYS = {"program grey light #64748b": "#64748b", "program grey dark #a8a6a0": "#a8a6a0"}


def lin(c):
    c /= 255
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def rgb(h):
    return [int(h[i:i + 2], 16) for i in (1, 3, 5)]


def lum(h):
    r, g, b = map(lin, rgb(h))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a, b):
    la, lb = sorted((lum(a), lum(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def lab(h):
    r, g, b = map(lin, rgb(h))
    x = (0.4124 * r + 0.3576 * g + 0.1805 * b) / 0.95047
    y = 0.2126 * r + 0.7152 * g + 0.0722 * b
    z = (0.0193 * r + 0.1192 * g + 0.9505 * b) / 1.08883
    f = lambda t: t ** (1 / 3) if t > 216 / 24389 else (24389 / 27 * t + 16) / 116  # noqa: E731
    fx, fy, fz = f(x), f(y), f(z)
    return 116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)


def de2000(h1, h2):
    L1, a1, b1 = lab(h1)
    L2, a2, b2 = lab(h2)
    C1, C2 = math.hypot(a1, b1), math.hypot(a2, b2)
    Cb = (C1 + C2) / 2
    G = 0.5 * (1 - math.sqrt(Cb ** 7 / (Cb ** 7 + 25 ** 7)))
    a1p, a2p = (1 + G) * a1, (1 + G) * a2
    C1p, C2p = math.hypot(a1p, b1), math.hypot(a2p, b2)
    h1p = math.degrees(math.atan2(b1, a1p)) % 360
    h2p = math.degrees(math.atan2(b2, a2p)) % 360
    dL, dC = L2 - L1, C2p - C1p
    dh = 0 if C1p * C2p == 0 else (h2p - h1p if abs(h2p - h1p) <= 180 else h2p - h1p - 360 if h2p > h1p else h2p - h1p + 360)
    dH = 2 * math.sqrt(C1p * C2p) * math.sin(math.radians(dh / 2))
    Lb, Cbp = (L1 + L2) / 2, (C1p + C2p) / 2
    if C1p * C2p == 0:
        hb = h1p + h2p
    elif abs(h1p - h2p) <= 180:
        hb = (h1p + h2p) / 2
    else:
        hb = (h1p + h2p + 360) / 2 if h1p + h2p < 360 else (h1p + h2p - 360) / 2
    T = (1 - 0.17 * math.cos(math.radians(hb - 30)) + 0.24 * math.cos(math.radians(2 * hb))
         + 0.32 * math.cos(math.radians(3 * hb + 6)) - 0.20 * math.cos(math.radians(4 * hb - 63)))
    dth = 30 * math.exp(-((hb - 275) / 25) ** 2)
    Rc = 2 * math.sqrt(Cbp ** 7 / (Cbp ** 7 + 25 ** 7))
    Sl = 1 + 0.015 * (Lb - 50) ** 2 / math.sqrt(20 + (Lb - 50) ** 2)
    Sc, Sh = 1 + 0.045 * Cbp, 1 + 0.015 * Cbp * T
    Rt = -math.sin(math.radians(2 * dth)) * Rc
    return math.sqrt((dL / Sl) ** 2 + (dC / Sc) ** 2 + (dH / Sh) ** 2 + Rt * (dC / Sc) * (dH / Sh))


oc = {m: v["colour"] for m, v in old["makers"].items()}
nc = {m: v["colour"] for m, v in new["makers"].items()}
used = set(new["setups"].values())
cols = {m: c for m, c in nc.items() if m in used}
L = ["| maker | setups | old | new | nearest other maker (ΔE2000) | nearest program grey (ΔE) | "
     + " | ".join(f"contrast vs {k}" for k in BG) + " |", "|---|---:|---|---|---|---|" + "---:|" * len(BG)]
for m, c in cols.items():
    near = min(((de2000(c, d), o) for o, d in cols.items() if o != m), default=(math.inf, "-"))
    ng = min((de2000(c, g), k) for k, g in GREYS.items())
    n = sum(1 for v in new["setups"].values() if v == m)
    L.append(f"| {m} | {n} | {oc.get(m, '(new maker)')} | {c} | {near[1]} {near[0]:.1f} | {ng[0]:.1f} | "
             + " | ".join(f"{contrast(c, b):.2f}" for b in BG.values()) + " |")
pairs = sorted((de2000(cols[a], cols[b]), a, b) for a, b in itertools.combinations(cols, 2))
dup = [m for m, c in cols.items() if list(cols.values()).count(c) > 1]
low = {k: min((contrast(c, b), m) for m, c in cols.items()) for k, b in BG.items()}
L += ["", f"- makers on the site: {len(cols)}; distinct colours: {len(set(cols.values()))}; shared: {dup or 'none'}",
      f"- minimum pairwise ΔE2000: {pairs[0][0]:.1f} ({pairs[0][1]} / {pairs[0][2]}); five lowest: "
      + "; ".join(f"{a} / {b} {d:.1f}" for d, a, b in pairs[:5]),
      "- lowest contrast per background: " + "; ".join(f"{k}: {v[0]:.2f} ({v[1]})" for k, v in low.items())]
open(sys.argv[3], "w").write("\n".join(L) + "\n")
print("\n".join(L))
