"""maker-colours (Ümit #3635): origin/main's render against the candidate's, both from the same frozen state. Reads only.

    python3 compare.py BASE_RENDER NEW_RENDER OUT_DIR

1. Files: same file set; every file byte-identical but the ones listed.
2. Each differing file: its numbers (every digit run, hex colours and the family-icon sprite taken out) as a multiset
   equal to origin/main's: 0 number changes.
3. Each differing file, normalised (hex colours -> #COLOUR; maker names -> MAKER; the family-icon sprite and the icon
   ids -> ICON): every remaining difference listed in compare.md (expected: none but legend swatches per maker).
Writes OUT_DIR/compare.md, manifest-main.tsv, manifest-candidate.tsv, render.diff; exits 1 on a number change or a
file only in one render."""
import difflib
import hashlib
import re
import sys
from collections import Counter
from pathlib import Path

base, new, out = (Path(a) for a in sys.argv[1:4])
out.mkdir(parents=True, exist_ok=True)
MAKERS = ["Maker not recorded", "Alibaba (Qwen)", "Alibaba", "Subquadratic", "SubQ", "REAX Labs", "REAX", "Blockbrain Labs",
          "Google", "Cloudflare", "Zefan Cai", "EldanRing", "TypeSafe", "Base Labs"]
HEX = re.compile(r"#[0-9a-fA-F]{6}\b|#[0-9a-fA-F]{3}\b")
SPRITE = re.compile(r'<svg class="family-sprite".*?</svg>', re.S)
ICON = re.compile(r'#fi-[a-z0-9-]+|fi-[a-z0-9-]+')
NUM = re.compile(r"\d+(?:[.,]\d+)*")
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()  # noqa: E731


def strip(t):
    return ICON.sub("ICON", HEX.sub("#COLOUR", SPRITE.sub("SPRITE", t)))


def norm(t):
    t = strip(t)
    for m in MAKERS:
        t = t.replace(m, "MAKER")
    return t


fb = {p.relative_to(base) for p in base.rglob("*") if p.is_file()}
fn = {p.relative_to(new) for p in new.rglob("*") if p.is_file()}
fail, lines, diff_out = [], [], []
for name, root, files in (("main", base, fb), ("candidate", new, fn)):
    (out / f"manifest-{name}.tsv").write_text("".join(f"{digest(root / f)}\t{f}\n" for f in sorted(files)))
only = sorted(fb ^ fn)
if only:
    fail.append(f"files only in one render: {only}")
changed = sorted(f for f in fb & fn if digest(base / f) != digest(new / f))
lines += [f"# maker-colours render comparison", "", f"- files: main {len(fb)}, candidate {len(fn)}, only in one: {len(only)}",
          f"- byte-different: {len(changed)}: " + ", ".join(f"`{f}`" for f in changed), "",
          "| file | numbers main | numbers candidate | number changes | other differences after colour/maker/icon normalising |",
          "|---|---:|---:|---:|---|"]
for f in changed:
    try:
        a, b = (base / f).read_text(), (new / f).read_text()
    except UnicodeDecodeError:
        fail.append(f"{f}: binary file differs")
        lines.append(f"| `{f}` | binary | binary | ? | binary differs |")
        continue
    na, nb = Counter(NUM.findall(strip(a))), Counter(NUM.findall(strip(b)))
    delta = (na - nb) + (nb - na)
    if delta:
        fail.append(f"{f}: number changes {dict(delta)}")
    sa = re.sub(r"(<|\n)", r"\n\1", norm(a)).splitlines()
    sb = re.sub(r"(<|\n)", r"\n\1", norm(b)).splitlines()
    d = [x for x in difflib.unified_diff(sa, sb, f"main/{f}", f"candidate/{f}", n=1, lineterm="")]
    diff_out += d
    other = sum(1 for x in d if x[:1] in "+-" and not x.startswith(("+++", "---")))
    lines.append(f"| `{f}` | {sum(na.values())} | {sum(nb.values())} | {sum(delta.values())} | {other} changed tag lines |")
(out / "render.diff").write_text("\n".join(diff_out) + "\n")
lines += ["", "**0 number changes.**" if not any("number" in x for x in fail) else "**NUMBER CHANGES: see failures.**",
          "", "## Failures", *(f"- {x}" for x in fail or ["none"])]
(out / "compare.md").write_text("\n".join(lines) + "\n")
print("\n".join(lines))
sys.exit(1 if fail else 0)
