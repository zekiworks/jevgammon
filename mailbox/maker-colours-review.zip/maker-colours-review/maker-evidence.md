# Maker names: the makers' own sources (read 2026-11-09 by MakerColours, direct GET through the reader)

The branch takes every maker name from the shared palette (maker_palette.json = logic's maker_colours.json, sha256
5f16a53f…7ec92c): a setup's maker is the palette maker whose `families` hold the setup's family (families.json).

| Model(s) on the backgammon site | Maker on live | Maker on the branch | Source (maker's own) | What it says |
|---|---|---|---|---|
| Jev 1.14.0, Jev 1.13.0 | TypeSafe | TypeSafe | https://docs.typesafe.ai/models.md ; https://typesafe.ai/blog/jev-1-14 (published 2026-11-06) | "Jev is TypeSafe's flagship model and the first System One model"; its models table lists Jev 1.14 and Jev 1.13. |
| Clef | Maker not recorded | **Cloudflare** | https://developers.cloudflare.com/changelog/post/2026-10-01-clef-workers-ai/ (**fetched** directly, via its index.md, not a search extraction) ; https://huggingface.co/Cloudflare/clef (HF author Cloudflare) | "Clef and Clef-flash, the first models trained by the Cloudflare Workers AI team"; title "Introducing Clef: Cloudflare's first open-source decision models, now on Workers AI". |
| Open-Jev 27B v1.1 | Maker not recorded (family Jev) | **Zefan Cai** (own family Open-Jev) | https://huggingface.co/ZefanCai/Open-Jev-27B-v1.1 (HF author ZefanCai) ; https://github.com/Zefan-Cai/Open-Jev | "A trained LoRA adapter and scalar decision head for the text backbone of Qwen/Qwen3.8-27B", loader github.com/Zefan-Cai/Open-Jev. Nothing there names TypeSafe. |
| Winnow-12B | Maker not recorded | **EldanRing** | https://huggingface.co/EldanRing/Winnow-12B | "Winnow-12B is an EldanRing fine-tune of Gemma 4 12B IT"; server github.com/EldanRing/winnow-inference. |
| Cygnet (Gemma 4 12B) | Google | **Blockbrain Labs** | https://github.com/blockbrain-ai/cygnet-recipe ; https://github.com/blockbrain-ai (org page title "Blockbrain Labs · GitHub") | "Cygnet answers … with frozen google/gemma-4-12B-it, no fine-tuning, served by unmodified vLLM": Blockbrain Labs' recipe, Google's weights (the setup's existing text, "Google's gemma-4-12B-it, unchanged", stays). |
| Base Labs Mammoth-1, Elephant-1 | Base Labs | Base Labs (one colour #1aa2eb) | https://labs.baseten.co/articles/mammoth-1-and-elephant-1-frontier-decision-models (2026-10-21) | Title "Mammoth-1 and Elephant-1: frontier decision models \| Base Labs"; "A core part of our process at Base Labs …". |
| SubQ Snap Preview, SubQ Snap 1.1 | SubQ | **Subquadratic** | https://subq.ai | Page title "SubQ Snap 1.1 — The first decision model for real enterprise work \| Subquadratic": the company is Subquadratic, SubQ the product. |
| REAX 1.3 | REAX Labs | **REAX** (and a REAX family, so it resolves) | https://huggingface.co/decisionmodels/REAX-1.3 (org decisionmodels) ; https://github.com/reaxlabs/reax-engine (org reaxlabs, "REAX Engine") | Neither page, as read, names a company "REAX Labs" or "REAX"; the palette's "REAX" is no worse than our old "REAX Labs" (from the GitHub org name). Not a conflict with a maker's own statement; noted for logic. |
| Qwen3.8 Flash, Qwen3.8-27B | Alibaba (Qwen) | **Alibaba** | palette: https://huggingface.co/Qwen | Same maker; label only. |
| (OneJev 27B: not on the backgammon site) | – | OmniJev (palette) | https://huggingface.co/OmniJev/OneJev-27B (HF author OmniJev; github.com/OmniJev/OneJev) | "OneJev-27B is the 27B model of OneJev, a multimodal System One decision model". A third author besides TypeSafe and Zefan Cai: three makers, three colours. |

Artificial Analysis's labels (Jev → TypeSafe, Clef → Cloudflare) agree with the makers' own sources.
No backgammon maker is missing from the palette; no palette name conflicts with a maker's own source.

Left unchanged: data/v3/improve.json (the Improve experiment's model list) still carries "Maker not recorded" for
some rows: it is copied verbatim from the committed plan "mailbox/Did they improve - plan 2026-11-08.md", not from
maker_colors.json.
