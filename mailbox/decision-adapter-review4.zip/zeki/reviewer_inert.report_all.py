"""Independent #3783 delta assertions. AST-only, virtual FS, memory SQL.
Creator: Zeki subagent. No production imports, supplied runner, or real DB.
"""
import ast, builtins, contextlib, hashlib, io, json, sqlite3, sys
from pathlib import Path
ROOT=Path(__file__).parent
source=(ROOT/'decision.py').read_text()
cohort=json.loads((ROOT/'zeki-inert/decision_cohort.json').read_text())
harness=ast.parse((ROOT/'zeki-inert/inert_review.adapted.py').read_text())
# Retain inspected imports, definitions, and literal constants; not supplied main/read/write code.
keep=[]
for node in harness.body:
    if isinstance(node,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.ClassDef)):
        keep.append(node)
    elif isinstance(node,ast.Assign) and all(isinstance(t,ast.Name) and t.id in {'NAMES','SUB','DREX'} for t in node.targets):
        keep.append(node)
ns={'TREE':ast.parse(source),'COHORT':cohort,'CHECKS':[]}
exec(compile(ast.Module(body=keep,type_ignores=[]),'inspected-inert-definitions','exec'),ns)
checks=[]
def check(name,detail,predicate=True):
    expected=not name.startswith('BUG_')
    checks.append({'name':name,'passed':bool(predicate)==expected,'predicate':bool(predicate),'detail':detail})
ns['check']=check
active=False
blocked=[]
def audit(event,args):
    if not active:return
    if event.startswith(('socket.','subprocess.','os.system','os.exec','os.spawn')) or event=='open':
        blocked.append(event);raise AssertionError('blocked effect '+event)
    if event=='sqlite3.connect' and not ('mode=memory&cache=shared' in str(args[0])):
        blocked.append(event);raise AssertionError('nonmemory SQL')
sys.addaudithook(audit)
err=io.StringIO()
active=True
try:
    with contextlib.redirect_stderr(err):
        for _f in ('money_checks','identity_checks','p1_checks'):
            try: ns[_f]()
            except Exception as _e: checks.append({'name':_f+' (section)','passed':False,'error':repr(_e)[:400]})
    env=ns['env'];V=ns['VPath'];SUB=ns['SUB'];DREX=ns['DREX']
    def ck(n,d,p=True):check(n,d,p)
    def expect_error(g,kind,fn):
        try:fn()
        except kind:return True
        return False
    g,I,c,sql=env()
    sql.fixture('/runs/decision/ghost-notes/ledgers/x.db',[('settled',.01,.01,'fixture')])
    ck('unknown_orphan_provider_fails_closed',None,expect_error(g,g['AccountingError'],lambda:g['admit'](DREX,'E1','/d',.01)))
    sql.close()
    g,I,c,sql=env()
    g['guard_record']=lambda:{'setups':{'subq-snap-1.1':{'refused':{'none':0,'worst':0}}}}
    identity=g['digest'](g['run_identity']('subq-snap-1.1'))
    g['evidence_record']=lambda *a:{'passed':True,'identity_sha256':identity}
    ck('current_p1_accepted',None,g['arm_state']('subq-snap-1.1','worst',False)[0]=='eligible')
    g['bind_run'](SUB)
    I.league_settings=lambda setup:{'name':setup,'fixture':True,'parallel':9}
    ck('effective_settings_p1_and_resume_refuse',None,g['arm_state']('subq-snap-1.1','worst',False)[0]=='pending' and expect_error(g,SystemExit,lambda:g['bind_run'](SUB)))
    I.league_settings=lambda setup:{'name':setup,'fixture':True}
    I.base_url_of=lambda key:'synthetic://override'
    ck('base_url_change_p1_and_resume_refuse',None,g['arm_state']('subq-snap-1.1','worst',False)[0]=='pending' and expect_error(g,SystemExit,lambda:g['bind_run'](SUB)))
    g['evidence_record']=lambda *a:{'passed':True}
    ck('legacy_p1_refuses',None,g['arm_state']('subq-snap-1.1','worst',False)[0]=='pending')
    sql.close()
    def chat(sql,cap=107.5,booked=2.0):
        p='/runs/chat/ledgers/S1-a1.db';rec=V('/runs/chat/S1/ledger.json')
        sql.fixture(p,[('settled',booked,booked,'fixture')]);rec.write_text(json.dumps({'path':p,'cap':cap}))
        return p,rec
    g,I,c,sql=env();p,rec=chat(sql)
    a=g['admit'](SUB,'E1','/a',.05,want=.75)
    ck('chat_headroom_reduces_total',a['limits'],abs(a['limits']['rule (b) limit']-2.5)<1e-9)
    ck('chat_headroom_reduces_writer_balance',None,ns['refuse'](g,lambda:g['admit']('decision/decider-v1.2-27b-notes','S1','/w',.005,balance=110)))
    (rec.parent/'aggregate.json').write_text('{}');ck('completed_chat_releases_future_headroom',None,g['chat_liabilities']()==[])
    del V.files[str(rec.parent/'aggregate.json')];rec.write_text('{bad')
    ck('malformed_chat_record_refuses',None,expect_error(g,g['AccountingError'],g['chat_liabilities']))
    sql.close()
    g,I,c,sql=env();a=g['admit'](SUB,'E1','/a',.01,want=.1);g['release'](a);g['release'](a)
    db=g['admission_db']();row=db.execute('SELECT id,key,provider,ledger,amount,status FROM allocations').fetchone();db.close()
    ck('precreation_and_repeat_release_conservative',g['committed'](row),g['committed'](row)==0)
    sql.fixture('/bad',[('settled',.1,None,'fixture')]);ck('invalid_settled_cost_refuses',None,expect_error(g,g['AccountingError'],lambda:g['booked_rows']('/bad')));sql.close()
    # Deterministic scheduling of actual decision functions: a chat settlement happens
    # after chat_booked(), before chat_liabilities() reads that ledger again.
    g,I,c,sql=env();p,rec=chat(sql,109.9,0)
    original=g['chat_booked']
    def interleaved():
        before=original();db=sql.connect(p);db.execute('UPDATE attempts SET reserved_usd=2,cost_usd=2');db.close();return before
    g['chat_booked']=interleaved
    a=g['admit'](SUB,'E1','/a',.5,want=.5)
    total=109.9+a['cap']
    ck('REPRO_split_chat_snapshot_understates_fixed_cap',{'cap':109.9,'booked_before':a['chat_booked'],'headroom_after':a['chat_open_headroom'],'decision_grant':a['cap'],'combined_max':total},total>110)
    sql.close()
    # A chat request reserved in SQLite can still be unsent/unbilled at the
    # provider: booked_rows counts it, but actual balance has not fallen yet.
    g,I,c,sql=env();p,rec=chat(sql,.03,0)
    db=sql.connect(p);db.execute("UPDATE attempts SET status='open',reserved_usd=.03,cost_usd=NULL");db.close()
    a=g['admit']('decision/decider-v1.2-27b-notes','S1','/writer',.005,balance=5.03)
    after=5.03-.03-a['cap']
    ck('REPRO_unbilled_chat_reservation_reuses_writer_reserve',{'actual_balance':5.03,'chat_open_attempt':.03,'chat_headroom':a['chat_open_headroom'],'new_writer_cap':a['cap'],'balance_after_both':after},after<5-1e-9)
    sql.close()
    # Read-only accounting is not a reservation respected by a later chat start.
    # The later cap is a synthetic environment input, NOT execution of absent improve.run.
    g,I,c,sql=env();p,rec=chat(sql,106.75,0);a=g['admit'](SUB,'E1','/a',.5,want=.5)
    p2='/runs/second/ledgers/E1-a1.db';sql.fixture(p2,[]);V('/runs/second/E1/ledger.json').write_text(json.dumps({'path':p2,'cap':3.0}))
    total=g['chat_booked']()+sum(x['headroom'] for x in g['chat_liabilities']())+a['cap']
    ck('REPRO_later_chat_admission_not_reserved_by_decision',{'existing_chat_cap':106.75,'later_synthetic_chat_cap':3.0,'chat_only_max':109.75,'decision_grant':a['cap'],'combined_max':total,'qualification':'synthetic later allocation; old chat runtime not executed'},total>110)
    sql.close()
finally:
    active=False
result={'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'checks':checks,'count':len(checks),'audit_blocks':blocked,'expected_stderr':err.getvalue(),'isolation':'AST-extracted functions; virtual FS; only shared-cache memory SQLite; audit-denied file open/network/subprocess during execution'}
print(json.dumps(result,indent=2))
