# maker-colours render comparison

- files: main 2552, candidate 2552, only in one: 0
- byte-different: 3: `clear-risk/index.html`, `index.html`, `leagues/index.html`

| file | numbers main | numbers candidate | number changes | other differences after colour/maker/icon normalising |
|---|---:|---:|---:|---|
| `clear-risk/index.html` | 4895 | 4895 | 0 | 0 changed tag lines |
| `index.html` | 10989 | 10989 | 0 | 97 changed tag lines |
| `leagues/index.html` | 83479 | 83479 | 0 | 104 changed tag lines |

**0 number changes.**

## Failures
- none
