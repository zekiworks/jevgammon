| setup | requests | max bytes | limit | refused none | refused notes (+19977 B) | refused worst (+2733 B) |
|---|---|---|---|---|---|---|
| Liquid d1-ultra | 5301 | 61393 | None | 5301 | 5301 | 5301 |
| Drex Max 1.1 | 2734 | 13823 | 262144 | 0 | 0 | 0 |
| Jev 1.14.0 | 4888 | 59869 | 32000 | 65 | 4888 | 81 |
| SubQ Snap 1.1 | 2330 | 48274 | 393216 | 0 | 0 | 0 |
