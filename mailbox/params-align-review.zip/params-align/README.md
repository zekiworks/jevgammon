# params-align review: parameter figures by the three sites' rule (logic #3508, Main #3506; Zeki #3510, #3529; logic #3534)

Branch `params-align`, **a482971**, on `deepseek-fix` 9d3bd27 (which is on origin/main 5e29f80). **Not merged.**
Presentation only: `tools/site/content/model_params.json`, two comments (pages.py, story.py: the 15B threshold is the
shared **provisional** one, #3471/#3473, not a human decision). No layout or feature change.

## Rule applied
The logical parameter count of the maker's own released checkpoint at its revision: the sum of the tensors' shapes
(never packed storage elements, quantization scales or buffers, never an adapter or assistant file standing for the
model), with its component scope; the maker's text kept in `quote`. A separate decision head file is shown as
'backbone X + decision head Y' (as logic will). No released weights: 'not disclosed by maker' unless the maker states a
figure. A card that gives parts but no whole-model total: its own terms, no total (DeepSeek V4.1 Flash). Each entry
records repo, file(s), revision, how counted and the maker's text (`quote`), and why (`note`).

## Every changed figure (origin/main = live → params-align)
| Row | Model | origin/main (live) | params-align | Small (≤15B) main → new |
|---|---|---|---|---|
| hl-6-box (main) | DeepSeek V4.1 Flash | 552B total / 16B active | 552B backbone + 196B conditional memory; active 8B (prefill) / 16B (decode) | – → – |
| hl-6-2-box (other) | DeepSeek V4.1 Flash | 552B total / 16B active | 552B backbone + 196B conditional memory; active 8B (prefill) / 16B (decode) | – → – |
| hl-11-box (main) | Gemma 4 31B | 30.7B | 31.27B | – → – |
| hl-11-1-box (other) | Gemma 4 31B | 30.7B | 31.27B | – → – |
| hl-13-box (main) | Base Labs Mammoth-1 | 27B | 27.36B | – → – |
| hl-14-box (main) | Drex Max v1 | 27B | backbone 26.09B + decision head 1.3M | – → – |
| hl-15-box (main) | Qwen3.8-27B | 27B | 27.78B | – → – |
| hl-15-1-box (other) | Qwen3.8-27B | 27B | 27.78B | – → – |
| hl-17-box (main) | REAX 1.3 | not disclosed by maker | part G 31.27B + part Q 26.09B + decision head 1.3M | – → – |
| hl-23-box (main) | Fastino GLiDE v1.2 | 26.09B | backbone 26.09B + decision head 1.3M | – → – |
| hl-25-box (main) | Decider v1.2 27B | 27B | backbone 26.09B + decision head 1.3M | – → – |
| hl-27-box (main) | Base Labs Elephant-1 | 9B | 9.41B | yes → yes |
| hl-28-box (main) | Clef | 27B | backbone 27.36B + joint head 128.1M | – → – |
| hl-29-box (main) | Cygnet (Gemma 4 12B) | 11.95B | 11.95B | yes → yes |
| hl-30-box (main) | Decider v1.1 27B | 26.09B | backbone 26.09B + decision head 1.3M | – → – |
| hl-34-box (main) | Winnow-12B | not disclosed by maker | 11.91B | – → yes |
| hl-36-box (main) | LFM2.5-24B-A2B | 24B total / 2.45B active | 23.97B total / 2.45B active | – → – |
| hl-36-1-box (other) | LFM2.5-24B-A2B | 24B total / 2.45B active | 23.97B total / 2.45B active | – → – |
| hl-37-box (main) | Decider Flash v1.2 | 4B | backbone 4.54B + decision head 0.7M | yes → yes |

Why, per row (details in each entry's quote/note):
- **DeepSeek V4.1 Flash**: the deepseek-fix commit (card's own terms; 552B is the backbone; no total, never Small).
- **Gemma 4 31B 30.7B → 31.27B, Qwen3.8-27B 27B → 27.78B, Mammoth-1 27B → 27.36B, Elephant-1 9B → 9.41B**: the
  checkpoint's logical total (Hugging Face's safetensors total for the maker's repo; language model + vision encoder;
  one weights set, no head file); the card's rounded figure in quote. Same as logic.
- **Decider v1.1, Decider v1.2, Drex Max v1, GLiDE v1.2 → 'backbone 26.09B + decision head 1.3M'; Decider Flash v1.2 →
  'backbone 4.54B + decision head 0.7M'; Clef → 'backbone 27.36B + joint head 128.1M'**: backbone = the shards in
  model.safetensors.index.json (Hugging Face's total, vision encoder included); head = readout.safetensors (1,305,600;
  Flash 652,800) or joint_head.safetensors (128,056,324, 122 tensors), counted from each file's header
  (`head-files.txt`, `scripts/st_header_count.py`). Decider v1.2: the same counts at cce0f3f8 and 225c913d (logic
  #3534). Totals (Small filter): 26.09B, 4.54B, 27.48B.
- **REAX 1.3 not disclosed → 'part G 31.27B + part Q 26.09B + decision head 1.3M' (57.36B)**: counted here from the 13
  part-g shard headers (31,273,088,876) + part-q's index total_parameters (26,085,330,160) + part-q/readout (1,305,600)
  at fa4bf7ee (`reax-headers.txt`); equals logic's 57.36B. BF16 storage, no scale tensors.
- **Winnow-12B not disclosed → 11.91B (joins Small models)**: gguf/Winnow-12B-Q8_0.gguf at the maker's revision
  0b5b7f98 (LFS sha256 b710efc4…, the same file the winnow-inference repo pins at d4631fb, logic #3534): 667 tensors,
  text model only; the sum of logical tensor shapes from the GGUF header = 11,907,350,576 (incl. a 256-element
  rope_freqs buffer; without it 11,907,350,320, the same 11.91B). Verified here twice: the header of the maker's file at
  that revision (range read) and the local copy (same sha256) — `winnow-gguf-count.txt`, `scripts/gguf_count.py`.
  Q8_0 blocks/scales are not counted (shapes only).
- **LFM2.5-24B-A2B 24B → 23.97B total** (2.45B active from the card): the checkpoint's BF16 total 23,971,585,280 at
  3dc4cd09 (F32 2,432 buffer elements not counted). Backgammon only.
- **Cygnet**: unchanged 11.95B, now linked to the card at the recipe's pinned revision 707f0a3b (deepseek-fix).

## Small models (threshold 15B, provisional)
origin/main: ranks 27, 29, 37 (3). params-align: #27 Base Labs Elephant-1 (9.41B), #29 Cygnet (Gemma 4 12B) (11.95B), #34 Winnow-12B (11.91B), #37 Decider Flash v1.2 (backbone 4.54B + decision head 0.7M) (4):
**Winnow-12B (#34) joins.**

## Open (left as on the live site)
- **DeepSeek V4.1 Flash 1017** ('not disclosed by maker'): logic has 552B / 16B from the V4.1-Flash card; the 1017 card
  says only 'a minor update', and its checkpoint total (763,205,315,794) counts packed FP4 experts as I8 elements, so no
  logical count is verified. Logic's entry also carries the backbone mislabel (to be relayed).
- **Open-Jev 27B v1.1** ('not disclosed by maker'): the released repo holds only the LoRA adapter and head (15,471,617
  trained parameters); logic's 27.80B adds the base Qwen3.8-27B, which the rule does not allow (an adapter file is not
  the model, and the base is not part of the release).
- **Drex 2.0 35B / 3B** kept as logic has it (the card's figures); the checkpoint's total at e6466744 is 35,107,181,936
  incl. the vision tower the card says is dropped on load — a scope decision for all three sites.
- **Kimi K3.1 Pro 2.8T / 104B** (card): its checkpoint stores experts packed (U8), so no logical count from the files.
- **GLM-5.3 753.33B**: Hugging Face's safetensors total (FP8 weights 751,226,191,872 + BF16 2,103,729,152 + F32 19,456,
  the F32 part possibly scales/buffers, < 0.01B, so the shown figure is unaffected); active not disclosed.
- Gemma 4 31B, Qwen3.8-27B, Clef, LFM2.5: the run's revision is not recorded; the repo's current revision was read.

## What ran
- Frozen copy of the live state `/tmp/pa-state` (2026-11-09 12:02:44Z under the update lock; data as of 11:50Z,
  results 7acf91cb).
- `/usr/bin/python3 tools/site/build.py --state /tmp/pa-state --no-image`: origin/main 5e29f80 `build-main.log`
  **exit 0**; params-align a482971 `build-candidate.log` **exit 0** (checks.run 0 failures).
- Counting scripts (read only): `gguf_count.py` (local file + maker's file header), `st_header_count.py` (HTTP range
  reads of safetensors headers).

## Results
## 1. Files
2552 files in origin/main's render, 2552 in the candidate's; only in one: none; different: ['index.html']

## 2. Rows and numbers
Leaderboard rows with a details box: origin/main 63, candidate 63.

Rows differing from origin/main beyond the Parameters line and data-hl-small: 0. Rows whose numbers (row + box, Parameters line out) differ: 0.

Home page outside the leaderboard table: text identical.

- **Rows:** 63 = 54 model + 9 program rows, 39 distinct models. **0 number changes** outside the Parameters lines
  (`numbers.csv`); every Parameters line = model_params.json and data-hl-small exactly on the ≤15B rows (`params.csv`;
  compare exit 0). `vs-deepseek-fix/compare.md`: the same checks against the deepseek-fix render (exit 0).
- **Browser:** **42/42, exit 0** (`browser.md`): 375/390/1280 light+dark; each filter state = data (Small models: 4 ranked rows, #27 #29 #34 #37), the line on all 63 rows (hover / tap), no overflow, no script error.

## Parameter table (all 39 models)
| Model | Shown | Source (revision in the URL or quote) | How counted / maker's text |
|---|---|---|---|
| Base Labs Elephant-1 | 9.41B | https://huggingface.co/baselabs/elephant-1/tree/b3f8a93462fb1051a9de031e94a7ff380e254072 | baselabs/elephant-1 @ b3f8a93462fb1051a9de031e94a7ff380e254072, model.safetensors (one file, no separate head file): 9,409,813,744 logical parameters (Hugging Face's safetensors total; language model 8,953,803,264 + vision encoder 456,010,480 per logic). Maker's text: 'a 9B parameter decision model'. |
| Base Labs Mammoth-1 | 27.36B | https://huggingface.co/baselabs/mammoth-1/tree/61cec44c281c693992e3d6ebeb44dd3402dfa186 | baselabs/mammoth-1 @ 61cec44c281c693992e3d6ebeb44dd3402dfa186, model.safetensors.index.json shards (no separate head file): 27,356,728,560 logical parameters (Hugging Face's safetensors total; language model 26,895,998,464 + vision encoder 460,730,096 per logic). Maker's text: 'a 27B parameter decision model'. |
| Celeris-1 Decision | not disclosed by maker | https://celeris.ai/celeris-1-decision | Launch post gives benchmarks, latency, price; no parameter count |
| Claude Fable 5.1 | not disclosed by maker | https://www.anthropic.com/claude-fable-and-mythos-5-1 | Searched the launch post, the API model docs page and the system/model card for 'parameter', 'billion', 'trillion' and figures like 'NB'/'NT'. No explicit parameter count was found (all cards fetched as full text unless noted). |
| Claude Opus 5.5 | not disclosed by maker | https://www.anthropic.com/claude-opus-5-5 | Searched the launch post, the API model docs page and the system/model card for 'parameter', 'billion', 'trillion' and figures like 'NB'/'NT'. No explicit parameter count was found (all cards fetched as full text unless noted). |
| Claude Sonnet 5.5 | not disclosed by maker | https://www.anthropic.com/claude-sonnet-5-5 | Searched the launch post, the API model docs page and the system/model card for 'parameter', 'billion', 'trillion' and figures like 'NB'/'NT'. No explicit parameter count was found (all cards fetched as full text unless noted). |
| Clef | backbone 27.36B + joint head 128.1M | https://huggingface.co/Cloudflare/clef/tree/cfddda043dd190ef3b01cff449d5ee8cff1e8ec6 | Cloudflare/clef @ cfddda043dd190ef3b01cff449d5ee8cff1e8ec6: backbone 27,356,728,560 logical parameters (model.safetensors.index.json shards, language model and vision encoder; Hugging Face's safetensors total) + joint head 128,056,324 (joint_head.safetensors, 122 tensors, its header's tensor shapes) = 27,484,784,884. Maker's text: the card: 'Clef is a 27B multimodal model…'; Cloudflare changelog '27B'. |
| Cygnet (Gemma 4 12B) | 11.95B | https://huggingface.co/google/gemma-4-12B-it/blob/707f0a3b8a3c7ad586ed01e27eafbad8a27dd0f7/README.md | Card at the pinned revision 707f0a3b8a3c7ad586ed01e27eafbad8a27dd0f7, '12B Unified' column: '/ **Total Parameters** / ... / 11.95B /'. Recipe: https://github.com/blockbrain-ai/cygnet-recipe (Google's gemma-4-12B-it, 'no fine-tuning', vLLM --revision 707f0a3b8a3c7ad586ed01e27eafbad8a27dd0f7). |
| Decider Flash v1.2 | backbone 4.54B + decision head 0.7M | https://huggingface.co/perplexity-ai/pplx-decider-flash-v1.2/tree/9ff7cf9838e59df461c276b7699d56b244d2af58 | perplexity-ai/pplx-decider-flash-v1.2 @ 9ff7cf9838e59df461c276b7699d56b244d2af58: backbone 4,539,265,536 logical parameters (model.safetensors.index.json shards, language model and vision encoder; Hugging Face's safetensors total) + decision head 652,800 (readout.safetensors, its header's tensor shapes) = 4,539,918,336. Maker's text: changelog: '`pplx-decider-flash-v1.2` is a new 4B decision model at \$0.01 per million input tokens.' |
| Decider v1.1 27B | backbone 26.09B + decision head 1.3M | https://huggingface.co/perplexity-ai/pplx-decider-v1.1-27b/tree/14c9d90137962d300f3de95633f7b6535e80c5ce | perplexity-ai/pplx-decider-v1.1-27b @ 14c9d90137962d300f3de95633f7b6535e80c5ce: backbone 26,085,330,160 logical parameters (model.safetensors.index.json shards, language model and vision encoder, 333 vision tensors in the index; Hugging Face's safetensors total) + decision head 1,305,600 (readout.safetensors, its header's tensor shapes) = 26,086,635,760. Maker's text: the card states no count. |
| Decider v1.2 27B | backbone 26.09B + decision head 1.3M | https://huggingface.co/perplexity-ai/pplx-decider-v1.2/tree/cce0f3f80033e9d89d80831d5281fd72124aacce | perplexity-ai/pplx-decider-v1.2 @ cce0f3f80033e9d89d80831d5281fd72124aacce (same counts at 225c913ddc8761a8264f04f64548e1f97e443eb3): backbone 26,085,330,160 logical parameters (model.safetensors.index.json shards, language model and vision encoder; Hugging Face's safetensors total) + decision head 1,305,600 (readout.safetensors, its header's tensor shapes) = 26,086,635,760. Maker's text: changelog: '`pplx-decider-v1.2` replaces `pplx-decider-v1.1-27b` as the 27B decision model'. |
| DeepSeek V4.1 Flash | 552B backbone + 196B conditional memory; active 8B (prefill) / 16B (decode) | https://huggingface.co/deepseek-ai/DeepSeek-V4.1-Flash | README at revision 314113f8a7dadb388215396ba5fbee2c610a04d6: 'a multimodal Mixture-of-Experts (MoE) model with 552B backbone parameters'; 'activate only **8B parameters per token during prefill** and **16B during decode**'; 'Engram conditional memory (196B parameters, sparsely accessed via token-based lookup)'; table '# Backbone Params 552B', '# Activated Params 8B / 16B'. |
| DeepSeek V4.1 Flash 1017 | not disclosed by maker | https://huggingface.co/deepseek-ai/DeepSeek-V4.1-Flash-1017 | Card states only: 'DeepSeek-V4.1-Flash-1017 is a minor update to DeepSeek-V4.1-Flash'; no parameter count on the 1017 card. |
| Drex 2.0 | 35B total / 3B active | https://huggingface.co/nace-ai/drex-v2.0/blob/e646674476744e3826caf62b834054151e2aba51/README.md | mixture-of-experts ... 40 layers, 256 experts and 8 active per token: 35B parameters in total, about 3B active per token |
| Drex Max 1.1 | not disclosed by maker |  | Maker's model reference, Drex Max guide and developer page list API id drex-max-v1.1, limits and pricing, but no parameter count; no open weights. |
| Drex Max v1 | backbone 26.09B + decision head 1.3M | https://huggingface.co/nace-ai/drex-max-v1/tree/cac65e1982a0237e996419ba559004522d9a33ac | nace-ai/drex-max-v1 @ cac65e1982a0237e996419ba559004522d9a33ac: backbone 26,085,330,160 logical parameters (model.safetensors.index.json shards, language model and vision encoder; Hugging Face's safetensors total) + decision head 1,305,600 (readout.safetensors, its header's tensor shapes) = 26,086,635,760. Maker's text: the card: 'a dense 27B-parameter model'. |
| Fastino GLiDE | not disclosed by maker |  | Hosted API (responses name glide_v2); the launch post and v1.2 post give no parameter count for the hosted model; the v1.2 post only says post-trained from 'an open weight 27B-class hybrid language model'. |
| Fastino GLiDE v1.2 | backbone 26.09B + decision head 1.3M | https://huggingface.co/fastino/GLiDE-27B/tree/a7e45896be7c96ba3354891da790c5ec99c30b6c | fastino/GLiDE (now fastino/GLiDE-27B) @ a7e45896be7c96ba3354891da790c5ec99c30b6c: backbone 26,085,330,160 logical parameters (model.safetensors.index.json shards, language model in 5 shards and vision encoder model-visual.safetensors 460,730,096, both in the index; Hugging Face's safetensors total) + decision head 1,305,600 (readout.safetensors, its header's tensor shapes) = 26,086,635,760. Maker's text: the card states no count; Fastino's blog: '27B-class'. |
| GLM-5.3 | 753.33B total; active not disclosed by maker | https://huggingface.co/api/models/zai-org/GLM-5.3 | safetensors.total: 753329940480 (BF16 2,103,729,152 + F8_E4M3 751,226,191,872 + F32 19,456), maker's own repo zai-org/GLM-5.3 @ ba32f8c19c8738e2c57c71798c601d477a7bf844 |
| GPT-6 Astra | not disclosed by maker | https://openai.com/index/gpt-6-astra/ | Searched the launch post, the API model docs page and the system/model card for 'parameter', 'billion', 'trillion' and figures like 'NB'/'NT'. No explicit parameter count was found (all cards fetched as full text unless noted). |
| GPT-6 Luna | not disclosed by maker | https://openai.com/index/introducing-gpt-6-sol-and-luna/ | Searched the launch post, the API model docs page and the system/model card for 'parameter', 'billion', 'trillion' and figures like 'NB'/'NT'. No explicit parameter count was found (all cards fetched as full text unless noted). |
| GPT-6.1 Sol | not disclosed by maker | https://openai.com/index/introducing-gpt-6-1-sol/ | Searched the launch post, the API model docs page and the system/model card for 'parameter', 'billion', 'trillion' and figures like 'NB'/'NT'. No explicit parameter count was found (all cards fetched as full text unless noted). |
| Gemini 3.8 Flash | not disclosed by maker | https://blog.google/innovation-and-ai/models-and-research/gemini-models/3-8-flash-and-3-8-flash-cyber/ | Searched the launch post, the API model docs page and the system/model card for 'parameter', 'billion', 'trillion' and figures like 'NB'/'NT'. No explicit parameter count was found (all cards fetched as full text unless noted). |
| Gemini 4 Argon | not disclosed by maker | https://blog.google/innovation-and-ai/technology/developers-tools/build-with-gemini-4-argon/ | Searched the launch post, the API model docs page and the system/model card for 'parameter', 'billion', 'trillion' and figures like 'NB'/'NT'. No explicit parameter count was found (all cards fetched as full text unless noted). |
| Gemma 4 31B | 31.27B | https://huggingface.co/google/gemma-4-31B-it/tree/842da3794eaa0b77d5f08bae87a17459d91ff475 | google/gemma-4-31B-it @ 842da3794eaa0b77d5f08bae87a17459d91ff475, model.safetensors.index.json shards: 31,273,088,876 logical parameters, BF16 (Hugging Face's safetensors total; language model and vision encoder). Maker's text: the card's table gives 30.7B plus a vision encoder. |
| Grok 4.7 | not disclosed by maker | https://x.ai/news/grok-4-7 | Searched the launch post, the API model docs page and the system/model card for 'parameter', 'billion', 'trillion' and figures like 'NB'/'NT'. No explicit parameter count was found (all cards fetched as full text unless noted). |
| Jev 1.13.0 | not disclosed by maker | https://docs.typesafe.ai/models | Models page lists model ID jev-1.13.0, price, context; no parameter count |
| Jev 1.14.0 | not disclosed by maker | https://docs.typesafe.ai/models | Models page lists model ID jev-1.14.0, price, context, release; no parameter count; launch blog has no count either |
| Kimi K3.1 Pro | 2.8T total / 104B active | https://huggingface.co/moonshotai/Kimi-K3.1-Pro/blob/main/README.md | Total Parameters / 2.8T ; Activated Parameters / 104B |
| LFM2.5-24B-A2B | 23.97B total / 2.45B active | https://huggingface.co/LiquidAI/LFM2.5-24B-A2B/tree/3dc4cd09c9a2a99e1e819693e79d3aba5e9bb4f2 | LiquidAI/LFM2.5-24B-A2B @ 3dc4cd09c9a2a99e1e819693e79d3aba5e9bb4f2, model.safetensors.index.json shards: BF16 23,971,585,280 logical parameters (Hugging Face's safetensors total; plus F32 2,432 buffer elements, not counted). Maker's text (card): 24B total, 2.45B active. |
| Liquid d1-ultra | not disclosed by maker | https://www.liquid.ai/blog/d1-ultra | Launch post ('Today, we release d1-ultra, our new multimodal decision model') states no parameter count. |
| Mercury Decide | not disclosed by maker |  | Inception's decisions docs, models page and Mercury 3 post describe the API (model id mercury-decide) but give no parameter count. |
| Open-Jev 27B v1.1 | not disclosed by maker | https://huggingface.co/ZefanCai/Open-Jev-27B-v1.1 | A trained LoRA adapter and scalar decision head for the text backbone of Qwen/Qwen3.8-27B ... It contains 15,471,617 trained parameters; upstream base-model weights are obtained separately. |
| Qwen3.8 Flash | not disclosed by maker | https://www.alibabacloud.com/help/en/model-studio/newly-released-models | qwen3.8-flash entries (2026-08-26 etc.) describe 'a multimodal model from the Qwen family ... million-token context window' with no parameter count. |
| Qwen3.8-27B | 27.78B | https://huggingface.co/Qwen/Qwen3.8-27B/tree/37561816e66b5b9153b1b64c10968c18c1e6f4a0 | Qwen/Qwen3.8-27B @ 37561816e66b5b9153b1b64c10968c18c1e6f4a0, model.safetensors.index.json shards: 27,781,427,952 logical parameters, BF16 (Hugging Face's safetensors total; language model and vision encoder). Maker's text: 'Number of Parameters: 27B'. |
| REAX 1.3 | part G 31.27B + part Q 26.09B + decision head 1.3M | https://huggingface.co/decisionmodels/REAX-1.3/tree/fa4bf7ee3bb56a8bc421dad090631be1c5845c2d | decisionmodels/REAX-1.3 @ fa4bf7ee3bb56a8bc421dad090631be1c5845c2d, the two parts of the blend: part-g, 13 shards model-000NN-of-00013.safetensors, 31,273,088,876 logical parameters (BF16; summed from each shard's header, scripts/st_header_count.py, reax-headers.txt); part-q, 11 shards, 26,085,330,160 (its model.safetensors.index.json 'total_parameters') + part-q/readout.safetensors 1,305,600 (F32, header) = 57,359,724,636. Weights stored in BF16 (served in FP8 on our GPU); no scale tensors counted. Maker's text: the card describes the two parts but states no count. |
| SubQ Snap 1.1 | not disclosed by maker | https://subq.ai/subq-snap-1-1 | Announcement covers training, calibration, benchmarks; no parameter count |
| SubQ Snap Preview | not disclosed by maker | https://subq.ai/introducing-subq-snap | Launch post gives benchmarks, price ($0.05/M input), Public Preview status; no parameter count |
| Winnow-12B | 11.91B | https://huggingface.co/EldanRing/Winnow-12B/blob/0b5b7f98e718cf0faffd0acea3093b86ebf00b56/gguf/Winnow-12B-Q8_0.gguf | EldanRing/Winnow-12B @ 0b5b7f98e718cf0faffd0acea3093b86ebf00b56, gguf/Winnow-12B-Q8_0.gguf (LFS sha256 b710efc4c0d048ee61eed92c5fef5ce323a4d17e7c51f9f0533cc72ae50818ea, the file the winnow-inference repo pins at d4631fb, logic #3534): 667 tensors, text model only (mmproj-Winnow-12B.gguf and the assistant GGUF not counted); the sum of the tensors' logical shapes from the GGUF header = 11,907,350,576 (token_embd 1,006,632,960 + blocks 10,900,713,520 + output_norm 3,840 + rope_freqs buffer 256), i.e. logical parameters, not Q8_0 storage blocks or scales. Counted here (scripts/gguf_count.py) from the maker's file at that revision (header read) and from the local copy (same sha256). Maker's text: no count. |

## Files
`compare.md`, `numbers.csv`, `params.csv`, manifests, `vs-deepseek-fix/`, `browser.md/csv`, `head-files.txt`,
`reax-headers.txt`, `winnow-gguf-count.txt`, `source.patch` (vs origin/main), `render-narrow.diff` (leaderboard
section), `for-umit/`, `screenshots/`, `scripts/`.
