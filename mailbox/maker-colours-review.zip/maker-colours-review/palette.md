| maker | setups | old | new | nearest other maker (ΔE2000) | nearest program grey (ΔE) | contrast vs light panel #f7f6f2 | contrast vs light page #dcd9d2 | contrast vs dark panel #1a1a18 | contrast vs dark page #0e0e0d |
|---|---:|---|---|---|---|---:|---:|---:|---:|
| OpenAI | 6 | #199e70 | #199e70 | REAX 14.2 | 25.4 | 3.15 | 2.42 | 5.12 | 5.67 |
| Google | 6 | #2a78d6 | #2a78d6 | Base Labs 15.3 | 12.7 | 4.08 | 3.13 | 3.95 | 4.37 |
| Anthropic | 6 | #d9653b | #d9653b | EldanRing 15.1 | 27.7 | 3.31 | 2.54 | 4.88 | 5.40 |
| xAI | 2 | #6250d6 | #6250d6 | Google 17.5 | 14.5 | 5.34 | 4.10 | 3.02 | 3.35 |
| DeepSeek | 4 | #a61e4d | #a61e4d | Moonshot 16.1 | 34.3 | 6.66 | 5.11 | 2.42 | 2.68 |
| Moonshot | 1 | #d55181 | #d55181 | Inception 13.1 | 31.0 | 3.65 | 2.80 | 4.42 | 4.90 |
| Liquid AI | 3 | #c98500 | #c98500 | Cloudflare 12.3 | 26.0 | 2.84 | 2.18 | 5.68 | 6.29 |
| Base Labs | 2 | #8f9399 | #1aa2eb | Google 15.3 | 21.1 | 2.62 | 2.01 | 6.15 | 6.82 |
| Alibaba | 3 | #8f9399 | #00829a | REAX 15.2 | 16.0 | 4.17 | 3.20 | 3.87 | 4.29 |
| Inception | 1 | #8f9399 | #d071bb | Moonshot 13.1 | 27.2 | 2.87 | 2.20 | 5.61 | 6.22 |
| Nace.AI | 4 | #8f9399 | #6b7f09 | Celeris 14.6 | 28.2 | 4.16 | 3.19 | 3.87 | 4.29 |
| Cloudflare | 1 | #8f9399 | #9f6700 | Liquid AI 12.3 | 29.4 | 4.40 | 3.38 | 3.66 | 4.06 |
| Z.ai | 1 | #8f9399 | #255640 | REAX 14.8 | 27.7 | 7.82 | 6.00 | 2.06 | 2.28 |
| Fastino | 2 | #8f9399 | #8f2400 | EldanRing 14.2 | 38.5 | 8.02 | 6.16 | 2.01 | 2.23 |
| Perplexity | 3 | #8f9399 | #645b2b | Zefan Cai 14.6 | 32.4 | 6.32 | 4.85 | 2.55 | 2.83 |
| Subquadratic | 2 | #8f9399 | #e814ff | Inception 14.5 | 28.6 | 3.25 | 2.49 | 4.96 | 5.50 |
| Celeris | 1 | #8f9399 | #6baa0e | Nace.AI 14.6 | 26.8 | 2.63 | 2.02 | 6.13 | 6.79 |
| EldanRing | 1 | #8f9399 | #965a40 | Fastino 14.2 | 29.8 | 5.07 | 3.89 | 3.18 | 3.53 |
| REAX | 1 | #8f9399 | #257e71 | OpenAI 14.2 | 22.7 | 4.51 | 3.46 | 3.57 | 3.96 |
| TypeSafe | 2 | #8f9399 | #bf9069 | Liquid AI 13.3 | 17.9 | 2.62 | 2.01 | 6.15 | 6.81 |
| Zefan Cai | 1 | #8f9399 | #704300 | Cloudflare 14.5 | 36.2 | 7.79 | 5.98 | 2.07 | 2.29 |
| Blockbrain Labs | 1 | #2a78d6 | #0eaaaa | REAX 16.0 | 24.0 | 2.64 | 2.03 | 6.10 | 6.76 |

- makers on the site: 22; distinct colours: 22; shared: none
- minimum pairwise ΔE2000: 12.3 (Liquid AI / Cloudflare); five lowest: Liquid AI / Cloudflare 12.3; Moonshot / Inception 13.1; Liquid AI / TypeSafe 13.3; Fastino / EldanRing 14.2; OpenAI / REAX 14.2
- lowest contrast per background: light panel #f7f6f2: 2.62 (Base Labs); light page #dcd9d2: 2.01 (Base Labs); dark panel #1a1a18: 2.01 (Fastino); dark page #0e0e0d: 2.23 (Fastino)
