"""maker-colours screenshots, Chromium (Playwright), the renders served over HTTP. Reads only.

    python3 browser.py HTTP_ROOT_URL BASE_NAME NEW_NAME OUT_DIR

At 375 and 1280 px, light and dark (the page's own theme buttons), main and candidate: the leaderboard and the
'flinch' bar chart; per view, the colours the page actually paints on the maker dots and bars (computed style) with
their maker (the dot's title), no sideways overflow, no script error. Writes OUT_DIR/browser.md, screenshots/."""
import json
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

root, base_name, new_name, out = sys.argv[1].rstrip("/") + "/", sys.argv[2], sys.argv[3], Path(sys.argv[4])
(out / "screenshots").mkdir(parents=True, exist_ok=True)
DOTS = """() => { const m = {}; document.querySelectorAll('#headline-table i.hl-dot').forEach(i => {
  const k = i.getAttribute('title'); (m[k] = m[k] || new Set()).add(getComputedStyle(i).backgroundColor); });
  return Object.fromEntries(Object.entries(m).map(([k, v]) => [k, [...v]])); }"""
rows, fail = [], []
with sync_playwright() as p:
    b = p.chromium.launch()
    for site in (base_name, new_name):
        for width in (375, 1280):
            for theme in ("light", "dark"):
                pg = b.new_page(viewport={"width": width, "height": 900}, color_scheme=theme)
                errs = []
                pg.on("pageerror", lambda e: errs.append(str(e)))
                pg.goto(root + site + "/", wait_until="networkidle")
                pg.click(f'[data-theme-choice="{theme}"]')
                pg.wait_for_timeout(200)
                over = pg.evaluate("() => document.documentElement.scrollWidth - innerWidth")
                dots = pg.evaluate(DOTS)
                tag = f"{'main' if site == base_name else 'candidate'}-{width}-{theme}"
                # The table scrolls inside its box: open it to full height so every maker's row is in the shot.
                pg.evaluate("""() => { let e = document.getElementById('headline-table');
                  for (; e && e.id !== 'leaderboard'; e = e.parentElement) { e.style.maxHeight = 'none'; e.style.overflow = 'visible'; } }""")
                pg.locator("#leaderboard").screenshot(path=str(out / "screenshots" / f"{tag}-leaderboard.png"))
                pg.locator("#finding-flinch").screenshot(path=str(out / "screenshots" / f"{tag}-chart-flinch.png"))
                ok = over <= 0 and not errs
                if not ok:
                    fail.append(f"{tag}: overflow {over}, errors {errs}")
                rows.append((tag, over, errs, dots))
                pg.close()
    b.close()
L = ["| view | sideways overflow (px) | script errors | maker dots in the leaderboard: painted colour(s) |", "|---|---:|---|---|"]
for tag, over, errs, dots in rows:
    L.append(f"| {tag} | {over} | {len(errs)} | " + "; ".join(f"{k}: {', '.join(v)}" for k, v in sorted(dots.items())) + " |")
L += ["", "Failures: " + ("; ".join(fail) if fail else "none")]
(out / "browser.md").write_text("\n".join(L) + "\n")
print("\n".join(L))
sys.exit(1 if fail else 0)
