"""Zeki review subagent: AST-only production functions, virtual FS and memory-only SQL.
No production module import, runner, subprocess, network, or on-disk DB.
"""
import ast, builtins, copy, fnmatch, hashlib, json, sqlite3, types, uuid, threading
from pathlib import Path, PurePosixPath
ROOT = Path('/tmp/decision-review3/zeki-inert')
SOURCE = (ROOT / 'decision.py').read_text()
TREE = ast.parse(SOURCE)
COHORT = json.loads((ROOT / 'decision_cohort.json').read_text())
CHECKS = []

def check(name, detail, predicate=True):
    # adapted: record whether the predicate holds instead of stopping at the first that does not
    CHECKS.append(dict(name=name, predicate_holds=bool(predicate), detail=detail))

class VPath:
    files = {}
    dirs = {'/', '/runs', '/runs/decision', '/state'}
    def __init__(self, p): self.p = str(p)
    def __str__(self): return self.p
    def __truediv__(self, p): return VPath(str(PurePosixPath(self.p) / str(p)))
    def __lt__(self, o): return self.p < str(o)
    @property
    def parent(self): return VPath(str(PurePosixPath(self.p).parent))
    @property
    def name(self): return PurePosixPath(self.p).name
    def exists(self): return self.p in self.files or self.p in self.dirs
    def is_dir(self): return self.p in self.dirs
    def mkdir(self, parents=False, exist_ok=False):
        if self.exists() and not exist_ok: raise FileExistsError(self.p)
        self.dirs.add(self.p)
        if parents:
            for p in PurePosixPath(self.p).parents: self.dirs.add(str(p))
    def read_text(self): return self.files[self.p]
    def write_text(self, v): self.files[self.p] = v
    def glob(self, pattern):
        base=self.p.rstrip('/')+'/'
        return [VPath(p) for p in self.files.keys() | self.dirs if p.startswith(base) and len(p[len(base):].split('/'))==len(pattern.split('/')) and fnmatch.fnmatchcase(p[len(base):],pattern)]

class MemorySQL:
    Error = sqlite3.Error
    def __init__(self): self.keepers={}; self.bad=set(); self.prefix=uuid.uuid4().hex
    def connect(self, path, **kwargs):
        p=str(path)
        if p.startswith('file:'): p=p[5:].split('?')[0]
        if p in self.bad: raise sqlite3.DatabaseError('synthetic corrupt ledger')
        if p not in self.keepers:
            uri='file:review_'+self.prefix+'_'+hashlib.sha256(p.encode()).hexdigest()+'?mode=memory&cache=shared'
            self.keepers[p]=(uri,sqlite3.connect(uri,uri=True,check_same_thread=False,isolation_level=None))
            VPath.files[p]='<memory-only database>'
        return sqlite3.connect(self.keepers[p][0],uri=True,check_same_thread=False,isolation_level=kwargs.get('isolation_level',None))
    def fixture(self,path,rows):
        VPath(path).parent.mkdir(parents=True,exist_ok=True)
        db=self.connect(path)
        db.execute('CREATE TABLE attempts (status TEXT,reserved_usd REAL,cost_usd REAL,setup TEXT)')
        db.executemany('INSERT INTO attempts VALUES (?,?,?,?)',rows);db.close()
    def close(self):
        for _,db in self.keepers.values(): db.close()

NAMES={'cohort','decided','setups','arm_key','split','register','guard_record','evidence_record','arm_state','digest','run_identity','money_terms','amended','bind_run','bound_run','writer_expect','AccountingError','Refused','booked_rows','arm_ledgers','arm_booked','chat_booked','provider_of','needs_ledger','admission_db','committed','admit','release','next_ledger','money_gate','provider_spent','p1_answer','probe_p1','arm_summary','chat_liabilities','chat_accounting','ledger_read'}
def env():
    VPath.files={}; VPath.dirs={'/','/runs','/runs/decision','/state'}
    sql=MemorySQL(); c=copy.deepcopy(COHORT)
    def forbidden(*a,**k): raise AssertionError('unmocked side effect')
    I=types.SimpleNamespace(RUNS=VPath('/runs'),STATE_ROOT=VPath('/state'),OUT=VPath('/out'),ENTRIES={},DRY=False,TOTAL_CAP_USD=110,ESTIMATE_FACTOR=1.5,BALANCE_RESERVE_USD=5,LESSON_PROMPT_SHA256='fixture-prompt',MODELS={'qwen3.8-flash-off':{'expect':{'models':['writer'],'provider':'fixture'}}},now=lambda:'fixture-time',share_cap=lambda:107,openrouter_balance=forbidden,log=lambda *a,**k:None,sha256_file=lambda p:'addendum',write_atomic=lambda p,v:p.write_text(v),check_inputs=lambda:None,V3_DB=VPath('/fixture-league'),PROMPT_VERSION='fixture',ORDER_SEED=1,TEST_CONTEXT={},BIN='/NEVER-EXECUTE',CODE='/NO-PROJECT')
    I.mdir=lambda key:I.RUNS/key
    I.league_settings=lambda setup:{'name':setup,'fixture':True}
    I.base_url_of=lambda key:None
    I.entry=lambda key:I.ENTRIES[key]
    I.pointer=lambda value,path:value.get("usage",{}).get("input_tokens")
    I.step_estimate=lambda key,step:.005
    imp=builtins.__import__
    def importer(name,*args,**kwargs):
        if name=='sqlite3':return sql
        if name=='uuid':return uuid
        raise AssertionError('unexpected extracted-function import '+name)
    g={'__builtins__':dict(vars(builtins),__import__=importer),'Path':VPath,'json':json,'hashlib':hashlib,'I':I,'sys':types.SimpleNamespace(stderr=__import__('sys').stderr),'subprocess':types.SimpleNamespace(run=forbidden),'ARMS':{'notes':'notes','worst':'worst'},'RUN_DEFINING':('setup','lane','provider','evidence','gate','expect','price','estimate','needs','needs_arms'),'WRITER_KEY':'qwen3.8-flash-off','WRITER_SUFFIX':' | writer','SERIES_SHARE':410/2650,'EMPTY_SHARE':200/2650,'ADDENDUM':VPath('/addendum'),'ADDENDUM_SHA256':'addendum','COHORT_FILE':VPath('/cohort'),'PREFLIGHT':lambda:VPath('/runs/decision/preflight')}
    exec(compile(ast.Module(body=[n for n in TREE.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in NAMES],type_ignores=[]),'decision.py extracted','exec'),g)
    g['cohort']=lambda:c
    g['register']()
    g['check_addendum']=lambda:None
    g['synthetic_notes_block']=lambda:'SYNTHETIC BLOCK'
    g['player_config']=lambda *a,**kw:{'name':a[1]}
    return g,I,c,sql

SUB='decision/subq-snap-1.1-worst'; DREX='decision/drex-max-1.1-worst'
def refuse(g,fn):
    try:fn()
    except g['Refused']:return True
    return False

def money_checks():
    g,I,c,sql=env()
    a=g['admit'](SUB,'E1','/runs/decision/subq-snap-1.1-worst/ledgers/a.db',.01,want=.6)
    b=g['admit']('decision/jev-1.14.0-worst','E1','/b',.01,want=.6)
    check('crash_without_release_holds_full_allocation',g['committed']((a['allocation'],SUB,'subq',a['ledger'],a['cap'],'open')),g['committed']((a['allocation'],SUB,'subq',a['ledger'],a['cap'],'open'))==.6)
    # Recreate extracted module globals while retaining the admission database (restart simulation).
    row=g['admission_db'](); held=row.execute("SELECT SUM(amount) FROM allocations WHERE status='open'").fetchone()[0];row.close()
    check('restart_persistent_allocation_read',held,abs(held-1.2)<1e-9)
    sql.fixture(a['ledger'],[('settled',.6,.1,'fixture')]);g['release'](a)
    db=g['admission_db']();rows=db.execute('SELECT id,key,provider,ledger,amount,status FROM allocations').fetchall();db.close()
    check('release_retains_actual_spend_and_other_open_hold',sum(g['committed'](r) for r in rows),abs(sum(g['committed'](r) for r in rows)-.7)<1e-9)
    sql.bad.add(b['ledger']);VPath.files[b['ledger']]='bad';g['release'](b)
    db=g['admission_db']();status=db.execute('SELECT status FROM allocations WHERE id=?',(b['allocation'],)).fetchone()[0];db.close()
    check('corrupt_release_keeps_allocation_open',status,status=='open')
    try:g['admit'](SUB,'E2','/new',.01)
    except g['AccountingError']:check('corrupt_ledger_refuses_admission','AccountingError')
    else:raise AssertionError('corrupt accepted')
    sql.close()
    g,I,c,sql=env()
    sql.fixture('/state/workspace/drex/state/nace-budget.db',[('open',2.5,None,'fixture')])
    check('external_nace_open_liability_refuses',True,refuse(g,lambda:g['admit'](DREX,'E1','/new',.01)))
    sql.close()
    g,I,c,sql=env()
    orphan='/runs/decision/drex-max-1.1-notes/ledgers/orphan.db'
    sql.fixture(orphan,[('settled',2.49,2.49,'fixture')])
    try:
        a=g['admit'](DREX,'E1','/new',.02,want=.02)
        check('BUG_orphan_provider_liability_omitted',{'orphan':2.49,'new_cap':a['cap'],'combined':2.49+a['cap'],'lane_used':a['lane_used']},2.49+a['cap']>2.5)
    except g['Refused'] as e:  # adapted: the fix refuses this admission
        check('BUG_orphan_provider_liability_omitted',{'refused':str(e)},False)
    sql.close()
    g,I,c,sql=env()
    # Two distinct local notes arms can run concurrently; no hosted lock applies.
    a=g['admit']('decision/decider-v1.2-27b-notes','S1','/a',.005,balance=5.03)
    try:
        b=g['admit']('decision/glide-v1.2-local-notes','S1','/b',.005,balance=5.03)
        check('BUG_writer_balance_reused_across_allocations',{'balance':5.03,'reserve':5,'caps':[a['cap'],b['cap']],'sum_caps':a['cap']+b['cap']},a['cap']+b['cap']>5.03-5+1e-9)
    except g['Refused'] as e:  # adapted: the fix refuses the second writer allocation
        check('BUG_writer_balance_reused_across_allocations',{'first_cap':a['cap'],'second':'refused: '+str(e)},False)
    sql.close()
    g,I,c,sql=env();I.share_cap=lambda:110
    check('old_share_110_refused',True,refuse(g,lambda:g['admit'](SUB,'E1','/a',.01)))
    I.share_cap=lambda:107;a=g['admit'](SUB,'E1','/a',.01,want=.1)
    check('share_107_allows_but_no_old_chat_headroom_input',a['share'],a['share']==107)
    sql.close()
    g,I,c,sql=env();g['admission_db']().close();results=[];lock=threading.Lock()
    def worker(n):
        try:out=('granted',g['admit'](SUB,'E1',f'/parallel-{n}',.05,want=.7)['cap'])
        except g['Refused']:out=('refused',0)
        except sqlite3.OperationalError as e:out=('memory_SQL_lock_refusal',0)
        with lock:results.append(out)
    ts=[threading.Thread(target=worker,args=(n,)) for n in range(12)]
    for t in ts:t.start()
    for t in ts:t.join()
    check('concurrent_memory_sql_admissions_lane_bounded',{'outcomes':results,'granted_total':sum(v for _,v in results),'qualification':'shared-cache SQLite can refuse locks immediately; not file-SQLite wait timing'},len(results)==12 and 0<sum(v for _,v in results)<=3+1e-9)
    sql.close()

def identity_checks():
    g,I,c,sql=env();key=SUB;stored=g['bind_run'](key)
    row=next(x for x in c['setups'] if x['slug']=='subq-snap-1.1');row['estimate']['worst']=9
    try:g['bind_run'](key)
    except SystemExit:check('changed_run_identity_refuses_resume','SystemExit')
    else:raise AssertionError('binding accepted')
    row['estimate']['worst']=.5;c['decision_lane_cap_usd']=2.9
    try:g['bind_run'](key)
    except SystemExit:check('unamended_money_change_refused','SystemExit')
    else:raise AssertionError('money accepted')
    c['amendments']=[{'path':'decision_lane_cap_usd','from':3,'to':2.9,'source':'fixture-authority'}]
    check('explicit_money_amendment_preserves_original_binding',g['bind_run'](key)['money']['decision_lane_cap_usd'],g['bind_run'](key)['money']['decision_lane_cap_usd']==3)
    g['guard_record']=lambda:{'setups':{'subq-snap-1.1':{'refused':{'none':0,'worst':0}}}}
    g['evidence_record']=lambda *a:{'passed':True,'identity_sha256':'wrong-identity'}
    state=g['arm_state']('subq-snap-1.1','worst',dry=False)
    check('BUG_mismatched_p1_identity_accepted',state,state[0]=='eligible')
    I.events=lambda key:[]
    out=g['arm_summary']('subq-snap-1.1','worst')
    check('export_contains_original_bound_setup_and_money',{'hash':out['bound_identity_sha256'],'money':out['bound_money']},out['bound_money']['decision_lane_cap_usd']==3 and out['bound_setup']==stored['identity']['setup'])
    sql.close()

def p1_checks():
    g,I,c,sql=env()
    # League SQL contains only synthetic placeholders; no private positions loaded.
    db=sql.connect('/fixture-league')
    for cmd in ['CREATE TABLE players(id INTEGER,name TEXT)','CREATE TABLE turns(id INTEGER,position TEXT,die1 INTEGER,die2 INTEGER,game_id INTEGER,legal_count INTEGER,decided_by TEXT,player INTEGER)','CREATE TABLE games(id INTEGER,match_id INTEGER)','CREATE TABLE matches(id INTEGER,valid INTEGER,player1 INTEGER,player2 INTEGER)']:db.execute(cmd)
    db.execute('INSERT INTO players VALUES (1,?)',('SubQ Snap 1.1',));db.execute("INSERT INTO turns VALUES(1,'{}',1,2,1,2,'model',1)");db.execute('INSERT INTO games VALUES(1,1)');db.execute('INSERT INTO matches VALUES(1,1,1,2)');db.close()
    calls=[]
    def ask(argv,**kw):
        a=dict(zip(argv[2::2],argv[3::2]));calls.append(a)
        db=sql.connect(a['--out']);db.execute('CREATE TABLE IF NOT EXISTS answers(id INTEGER PRIMARY KEY,setup TEXT,error TEXT)');db.execute('CREATE TABLE IF NOT EXISTS answer_exchanges(answer_id INTEGER,response TEXT)')
        cur=db.execute('INSERT INTO answers(setup,error) VALUES (?,NULL)',(a['--setup'],))
        db.execute('INSERT INTO answer_exchanges VALUES (?,?)',(cur.lastrowid,json.dumps({'model':'subq-snap-1.1','usage':{'input_tokens':100 if len(calls)%2 else 200}})));db.close()
        return types.SimpleNamespace(returncode=0,stdout='',stderr='')
    good=g['probe_p1']('subq-snap-1.1',send=True,run=ask)
    failed=g['probe_p1']('subq-snap-1.1',send=True,run=lambda *a,**k:types.SimpleNamespace(returncode=1,stdout='',stderr='fixture'))
    check('p1_fresh_success_then_failed_rerun_does_not_reuse',{'first':good['passed'],'second':failed['passed'],'different_attempts':good['attempt']!=failed['attempt']},good['passed'] and not failed['passed'] and good['attempt']!=failed['attempt'])
    p=c['provider_ledgers']['nace'][0];sql.fixture('/state/'+p,[('open',2.5,None,'fixture')]);before=len(calls)
    check('p1_exhausted_external_nace_refuses_before_mock_dispatch',True,refuse(g,lambda:g['probe_p1']('drex-max-1.1',send=True,run=ask)) and len(calls)==before)
    sql.close()

money_checks();identity_checks();p1_checks()
print(json.dumps(CHECKS,indent=2))
