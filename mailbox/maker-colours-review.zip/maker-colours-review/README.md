# maker-colours: one colour and one name per maker, from the shared palette (Ümit #3635; logic #3668)

Branch `maker-colours` (candidate, not merged), one code commit on origin/main 0f7c152. Presentation only.

## What changed (`source.patch`, tools/site only)
- `content/maker_palette.json`: logic's shared `maker_colours.json`, **byte-identical**, sha256
  `5f16a53f3a032faf64c54428cd510566bc6cb9528cae975e17f72f3c407ec92c` (35 makers). `checks.py` fails the build if the
  file's hash is not the one `maker_colors.json` records.
- `content/maker_colors.json`: now only the about text and that hash; the old per-setup maker list and the grey
  colours are gone. A setup's maker (name and colour) is the palette maker whose `families` hold the setup's family
  (`families.json`, home.py `maker()`); a setup without a family, or a family held by 0 or 2+ makers, fails the build.
  Legends follow the palette's order.
- `content/families.json`: Open-Jev is its own family (was under Jev); REAX gets a family (it had none, so it could
  not resolve to a palette maker).
- `content/family_icons.svg`: each badge icon's square in its maker's palette colour (Mammoth now #1aa2eb like
  Elephant; Fastino, SubQ, Jev, Celeris, Cygnet, Winnow recoloured; Drex, Clef, Inception, Elephant already equal),
  the mark white or #111, whichever contrasts more (≥ 4.5:1 for all). New icons fi-open-jev (outlined diamond) and
  fi-reax (square). Brand-logo icons (Gemini, GPT, Claude, …) stay text-coloured.
- `story.py`: the "Maker not recorded" special case removed (no setup lacks a maker now), so Clef, Winnow-12B and
  Open-Jev show their maker in the details line like every other model.

## Builds and checks (fresh frozen state)
- State: `cp -a ~/.local/state/bg-site /tmp/mc-state` under the update lock at 2026-11-09T14:52:52Z (data as of
  14:50Z, results e8a71a84 = the live push of 14:52:51Z), plus the repo's untracked build inputs (replay.db,
  smoke/part-a.json, workspace/learning-pilot, workspace/improve, untracked positions/) copied into both trees.
- `build.py --state /tmp/mc-state --no-image` (full compute, render, checks.run): origin/main `build-main.log`
  **exit 0**; branch `build-candidate.log` **exit 0** (checks.run 0 failures, incl. the new palette hash check).
- `compare.md` (scripts/compare.py): 2,552 files each, none only in one; byte-different only `index.html`,
  `leagues/index.html`, `clear-risk/index.html`; **0 number changes** (number multisets equal per file, hex colours
  and the icon sprite aside). What remains after normalising colours/maker names/icon ids (`render.diff`): legend
  swatches (one per maker now, palette order), the maker in the details line of Clef / Winnow-12B / Open-Jev, and the
  REAX row's new icon. The old maker grey #8f9399 occurs 0 times in the candidate (main: 163 + 158 + 17).
- `browser.md` (scripts/browser.py, Chromium): 375 and 1280 px, light and dark, main and candidate: no sideways
  overflow, no script error; the colours the page paints on every maker dot listed per view. Screenshots in
  `screenshots/`: the leaderboard opened to full height and the "flinch" bar chart, each view main and candidate.

## Palette (`palette.md`; `palette-plain.json` maker → hex for the other sites; `maker_palette.json` the shared file)
- 22 makers on the backgammon site, 22 distinct colours, none shared; Ümit's 7 unchanged; Base Labs #1aa2eb for
  Mammoth and Elephant; programs stay the site's program grey (--data-grey #64748b light / #a8a6a0 dark).
- Minimum CIEDE2000 among the backgammon makers **12.3** (Liquid AI #c98500 / Cloudflare #9f6700); whole palette
  (35 makers) 12.03 (Anthropic / Metask Lab), 28 pairs below 15. The ΔE ≥ 15 aim is not met by the shared palette.
- WCAG contrast on our backgrounds (own measurement): lowest vs light panel #f7f6f2 2.62 (Base Labs), light page
  #dcd9d2 2.01 (Base Labs), dark panel #1a1a18 2.01 (Fastino), dark page #0e0e0d 2.23 (Fastino). Below 3:1 on the
  panel: light — Base Labs, Blockbrain Labs, Celeris, Inception, Liquid AI (Ümit's), TypeSafe; dark — DeepSeek
  (Ümit's), Fastino, Perplexity, Z.ai, Zefan Cai. The palette's floor is 2.0 (logic's measurement agrees). Not
  patched here (the file must stay byte-identical).

## Maker names (`maker-evidence.md`)
Jev → TypeSafe (docs.typesafe.ai/models.md), Clef → Cloudflare (Cloudflare changelog, fetched directly), Open-Jev →
Zefan Cai, Winnow → EldanRing, Cygnet → Blockbrain Labs, SubQ → Subquadratic, REAX Labs → REAX, Alibaba (Qwen) →
Alibaba, OneJev → OmniJev (not on this site). No backgammon maker is missing from the palette.

Not run: update.sh, deploy, scorers, model calls.
