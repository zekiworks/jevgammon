runner (src/) unchanged since bb74f07: pinned binary target/release/jevgammon-bb74f07 sha256 aafea7fb6d7b78e052cc84484e5910ff69ef009368ca59d839b96fe226ceeb42 still applies
branch improve-decision f9721c0b84f2c95353e4e8f506ef886dd472891c; base of this packet bb74f07; review #3769/#3772
