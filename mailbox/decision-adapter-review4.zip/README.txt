Zeki #3784 corrections, improve-decision c540044 (diff-vs-488c91f.patch). No calls; no chat-lane change.
Tests: cargo-test.txt 99 exit 0; test_decision.txt 35 exit 0; test_improve.txt 31 exit 0.

Partition rule (decision.py chat_accounting / admit): chat lanes read runs/share_cap.json ($107) at every billed step start
(pinned ~/code/jevgammon-improve @ 56a93b4 workspace/improve/improve.py: run() line 1173 money_gate once per step; money_gate
line 381 share = share_cap(), line 389 cap = ledger_cap(...) (limit "share" = share - total); new_ledger 837-843; run_empty /
run_series 848-850 / 869-871 write <model>/<step>/ledger.json with the gate incl. "share"; player_config line 242 makes the cap
the runner's budget cap_usd). The decision lane's hard cap is $3.00; $107 + $3.00 = $110. The partition holds once no open chat
step (ledger.json without aggregate.json) was capped under a share above $107 or with no recorded share; until then every
decision admission waits (Refused, pause) and names the blocking steps. Fixes 1-2 (one read per ledger, max(booked, cap) for open
steps; open and lost reservations as balance liabilities) stay as in-lane safety.
Blocking now (blocking-steps-now.json): DeepSeek V4.1 Flash (on) S1, share $110, cap $61.97. Kimi K3.1 Pro (off) S1 was capped
under share $21.96 (below $107): it does not block (its ledger.json predates 16:34:49Z but its cap came from a smaller share).

Zeki's reviewer_inert.py (zeki/reviewer_inert.py, byte-identical to his file, cmp OK):
- zeki/names-adaptation.diff: the only change to its inputs: the extracted-name list in the inspected definitions
  (zeki-inert/inert_review.adapted.py) gains chat_accounting and ledger_read (new functions; without them extraction fails).
  Every assertion unchanged.
- Strict run (zeki/output.json, stderr.txt, exit.txt = 1): money_checks, identity_checks and p1_checks complete with every
  strict assertion (all BUG_ cases absent); it then stops at the first chat fixture: that fixture's ledger.json has no gate share,
  so the new partition refuses admission (by design: an unrecorded share blocks).
- zeki/reviewer_inert.report_all_share107.py (diff in report-all-share107-adaptation.diff): same assertions recorded instead of
  raised, chat fixtures given gate share 107. It stops at REPRO_split_chat_snapshot_understates_fixed_cap: with the fix the
  admission is refused (rule (b) leaves $0.10 < $0.50) instead of granting $0.50, so the reproduction no longer reproduces
  (stderr.share107.txt). The remaining REPRO cases are covered by test_decision.py (unbilled open/lost chat reservation,
  one read per ledger, old-share step blocks / $107 step does not).
Runner (src/) unchanged since bb74f07: pinned binary target/release/jevgammon-bb74f07.
